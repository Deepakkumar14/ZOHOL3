package zkart;

import java.util.ArrayList;
import java.util.List;

public class Cart {
        private long InvoiceNumber;
    public long getInvoiceNumber() {
        return InvoiceNumber;
    }

    public void setInvoiceNumber(long invoiceNumber) {
        InvoiceNumber = invoiceNumber;
    }
    public List<Products> getInvoiceList() {
        return invoiceList;
    }

    public void setInvoiceList(List<Products> invoiceList) {
        this.invoiceList = invoiceList;
    }

    private List<Products> invoiceList;
}
