package zkart;



import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

public class Logical {

    public void setAdmin(){
        String encrypt=encryption("xyzzy");
        Cache.INSTANCE.setAdminLogin("admin@zoho.com",encrypt);
    }

    public String customerLoginChecker(String mail, String password){
        if(mail!=null &&password!=null) {
            Customer cus = Cache.INSTANCE.getCustomer(mail);
            if(cus!=null) {
                String password1 = cus.getPassword();
                String decrypt = decryption(password1);
               // System.out.println(decrypt);
                if (decrypt.equals(password)){
                    return "true";
                }
                else
                    return "Enter valid password";
            }else
                return "Enter valid mailId";
        }else
            return "Enter valid email and password";
    }

    public String adminChecker(String mail,String password){
        if(mail!=null &&password!=null) {
            Admin admin = Cache.INSTANCE.getadmin();
            if(admin!=null) {
                String password1 = admin.getPassword();
                String decrypt = decryption(password);
                if (decrypt.equals(password1)){
                    return "true";
                }
                else
                    return "Enter valid password";
            }else
                return "Enter valid mailId";
        }else
            return "Enter valid email and password";
    }


    public String encryption(String password){
        String encrypt="";
        for(int i=0;i<password.length();i++){
            if(password.charAt(i)=='Z') {
                encrypt += 'A';
                continue;
            }
            encrypt+=(char)((int)password.charAt(i)+1);
        }
        return encrypt;
    }

    public String decryption(String password){
        String decrypt="";
        for(int i=0;i<password.length();i++){
            decrypt+=(char)((int)password.charAt(i)-1);
        }
       return decrypt;
    }

    public void fileReader()  {
        FileReader fr = null;
        try {
            File file = new File("/home/inc4/zusers_db.txt");
            fr = new FileReader(file);
            BufferedReader br = new BufferedReader(fr);
            String lines;
            while ((lines = br.readLine()) != null) {
                String[] array=lines.split("\\s");
                Customer cus=new Customer();
                cus.setMail(array[0]);
                cus.setPassword(array[1]);
                cus.setName(array[2]);
                cus.setMobile(Long.parseLong(array[3]));
                Cache.INSTANCE.setCustomer(cus);
            }
        }catch(IOException ex) {
            System.out.println(ex);
        }finally {
            try {
                fr.close();
            }catch(IOException ex) {
                System.out.println(ex);
            }
        }
    }

    public String passwordChecker(String password){
        if(password!=null){
            //String regex="^(?=.)"
        }
        return "false";
    }

    public void adminPasswordChanger(String password) {
      String encrypt= encryption(password);
      Admin admin=Cache.INSTANCE.getadmin();
      admin.setPassword(encrypt);
      List<String> password1=admin.getPasswords();
      password1.add(encrypt);
    }

    public LinkedHashMap<String, HashMap<String, Products>> getProductmap() {
        return Cache.INSTANCE.productsmap();
    }

    public String maildIDChecker(String mailId) {
        if (mailId!=null){
           HashMap<String,Customer> map=Cache.INSTANCE.customerMap();
           if(map.containsKey(mailId)){
               return "Mail id already available";
           }else
               return "false";
        }
        return "Enter valid mailId";
    }

    public String setCustomer(Customer cus) {
        if(cus!=null) {
            String encrypt = encryption(cus.getPassword());
            cus.setPassword(encrypt);
            Cache.INSTANCE.setCustomer(cus);
            return "Customer Added successfully";
        }else
        return "Customer not added";
    }

    public void addToCart(Products products, String mail) {
        Cache.INSTANCE.addToCart(products,mail);
    }

    public List<Products> checkout(String mail) {
        List<Products> list=Cache.INSTANCE.checkout(mail);
        return list;
    }

    public Cart getInvoiceList(String mail) {
        Cart list=Cache.INSTANCE.getInvoiceList(mail);
        return  list;
    }

    public String CustomerPasswordChanger(String newPassword, String mail) {
        if(newPassword!=null) {
            String encrypt = encryption(newPassword);
            HashMap<String, Customer> cus = Cache.INSTANCE.customerMap();
            Customer person = cus.get(mail);
            List<String> password1 = person.getPasswords();
            if(password1==null)
                password1=new ArrayList<>();
            password1.add(encrypt);
            person.setPassword(encrypt);
            return "Password changed Successfully";
        }
        return "Password was not changed try again";
    }

    public void itemsReader()  {
        FileReader fr = null;
        try {
            File file = new File("/home/inc4/z_kart_db.txt");
            fr = new FileReader(file);
            BufferedReader br = new BufferedReader(fr);
            String lines;
            while ((lines = br.readLine()) != null) {
                String[] array=lines.split("\\s");
                Products cus=new Products();
                cus.setCategory(array[0]);
                cus.setBrand(array[1]);
                cus.setModel(array[2]);
                cus.setPrice(array[3]);
                cus.setStock(Integer.parseInt(array[4]));
                Cache.INSTANCE.setProductsMap(cus);
            }
        }catch(IOException ex) {
            System.out.println(ex);
        }finally {
            try {
                fr.close();
            }catch(IOException ex) {
                System.out.println(ex);
            }
        }
    }
}
