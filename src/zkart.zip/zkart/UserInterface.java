package zkart;


import java.util.*;

public class UserInterface {
    private Scanner input=new Scanner(System.in);
    private Logical logic=new Logical();
    public static void main(String[] args) {
        UserInterface user=new UserInterface();
            user.logic.setAdmin();
        user.logic.fileReader();
        user.logic.itemsReader();
           user.login();
    }

    public void login() {
        int choice;
        int temp = 0;
        System.out.println("1.Sign in\n2.Sign up");
        choice = input.nextInt();
        input.nextLine();
        switch (choice) {
            case 1: {
                System.out.println("1.Customer\n2.Admin");
                choice = input.nextInt();
                input.nextLine();
                if (choice == 1) {
                    System.out.println("Enter mailId");
                    String mail = input.nextLine();
                    System.out.println("Enter password");
                    String password = input.nextLine();
                    String output = logic.customerLoginChecker(mail, password);
//                   if (output.equals("true")) {
                          customerUserInterface(mail);
//                    } //else
                        //System.out.println(output);
                } else if (choice == 2) {
                    System.out.println("Enter mailId");
                    String mail = input.nextLine();
                    System.out.println("Enter password");
                    String password = input.nextLine();
                    String output = logic.adminChecker(mail, password);
                    if (output.equals("true")) {
                        if (temp++ == 0) {
                            System.out.println("You need to change the password\nEnter old new password");
                            String newPassword = input.nextLine();
                            String output1 = logic.passwordChecker(newPassword);
                            while (!output1.equals("true")) {
                                System.out.println(output);
                                newPassword = input.nextLine();
                            }
                            logic.adminPasswordChanger(newPassword);
                        }
                        adminUserInterface(mail, password);
                    } else
                        System.out.println(output);
                } else
                    System.out.println("Enter valid input");
                login();
                break;
            }
            case 2: {
                Customer cus = new Customer();
                System.out.println("Enter mailId");
                String mailId = input.nextLine();
                String output = logic.maildIDChecker(mailId);
                if (!output.equals("false")) {
                    System.out.println(output);
                } else {
                    System.out.println("Enter name");
                    String name = input.nextLine();
                    System.out.println("Enter mobile");
                    long mobile = input.nextLong();
                    input.nextLine();
                    System.out.println("Enter password");
                    String password = input.nextLine();
                    //String output1=logic.passwordChecker(password);
//                    if(!output1.equals("true")){
//                        System.out.println(output);
//                    }else {
//                        System.out.println("Enter password again to Confrim");
//                        String confirm=input.nextLine();
//                        while(confirm!=password){
//                            System.out.println("Enter password again");
//                            confirm=input.nextLine();
//                        }
                    cus.setMail(mailId);
                    cus.setPassword(password);
                    cus.setName(name);
                    cus.setMobile(mobile);
                    List<String> list = cus.getPasswords();
                    if(list==null){
                        list=new ArrayList<>();
                    }
                    list.add(password);
                    cus.setPasswords(list);
                    String output2 = logic.setCustomer(cus);
                    System.out.println(output2);
                    login();
                    break;
                }
            }

            default: {
                System.out.println("Enter valid input");
                login();
                break;
            }
        }
    }

    private void adminUserInterface(String mail, String password) {
        System.out.println("1.Display items\n2.Reorder");
        int choice=input.nextInt();
        switch (choice){
            case 1:{
                LinkedHashMap<String,HashMap<String,Products>> products=Cache.INSTANCE.productsmap();
                for(Map.Entry<String, HashMap<String, Products>> map:products.entrySet()){
                    HashMap<String, Products> map1=map.getValue();
                    for(Map.Entry<String, Products> map2:map1.entrySet()){
                        if(map2.getValue().getStock()<10)
                            System.out.println(map2.getValue());
                    }
                }
            }

        }

    }

    private void customerUserInterface(String mail) {
        int choice=0;
        System.out.println("1.Add list to cart\n2.Print invoice\n3.change password");
        choice=input.nextInt();
        input.nextLine();
        switch (choice){
            case 1:{
                LinkedHashMap<String,HashMap<String,Products>> map=logic.getProductmap();
                int i=1;
               for(Map.Entry<String,HashMap<String,Products>> map1:map.entrySet())
                   System.out.println(i++ +" "+map1.getKey());
                System.out.println("Choose a category ");
                String category=input.nextLine();
                HashMap<String,Products> brands=map.get(category);
                for(Map.Entry<String,Products> brand:brands.entrySet())
                    System.out.println(brand.getKey()+"  "+brand.getValue().getModel());
                System.out.println("Choose a brand and model to add to cart");
                String brand=input.nextLine();
                System.out.println("Choose the model");
                String model=input.nextLine();
                Products product=brands.get(brand);
                if(product.getStock()!=0) {
                    logic.addToCart(brands.get(brand),mail);
                }
                else
                    System.out.println("Product not available");

                System.out.println("Do you want to add any other product......Enter 1");
                System.out.println("Do you want to checkout the cart......Enter 2");
                choice=input.nextInt();
                input.nextLine();
                if(choice==1)
                    customerUserInterface(mail);
                else if(choice==2) {
                    List<Products> list1 = logic.checkout(mail);
                    System.out.println(list1);
                    System.out.println("Your invoice is");
                     i=0;
                    for(Products list:list1){
                            System.out.println(list);
                        }
                }
                customerUserInterface(mail);
                break;
            }
            case 2:{
                System.out.println("Your invoice bill is");
                Cart cart=logic.getInvoiceList(mail);
                List<Products> list1=cart.getInvoiceList();
                System.out.println("Your invoice is");
                    System.out.println("Invoice Id "+cart.getInvoiceNumber());
                    for(Products product:list1) {
                        System.out.println(product);
                    }
                customerUserInterface(mail);
                break;
            }
            case 3:{
                System.out.println("Enter the new password ");
                String newPassword = input.nextLine();
                HashMap<String,Customer> customerLogi= Cache.INSTANCE.customerMap();
                for(Map.Entry<String,Customer> map:customerLogi.entrySet()){
                    System.out.println(map.getKey()+map.getValue());
                }
//                String output1=logic.passwordChecker(newPassword);
//                while (!output1.equals("true")){
//                    System.out.println(output1);
//                    newPassword=input.nextLine();
//                }
               String output= logic.CustomerPasswordChanger(newPassword,mail);
                HashMap<String,Customer> customerLogin= Cache.INSTANCE.customerMap();
                for(Map.Entry<String,Customer> map:customerLogin.entrySet()){
                    System.out.println(map.getKey()+map.getValue());
                    //System.out.println();
                }
                System.out.println(output);

                login();
                break;
            }
        }

    }
}
