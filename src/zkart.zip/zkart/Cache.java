package zkart;

import java.util.*;

public enum Cache {
    INSTANCE;

    private static  long invoice=310000;
    private HashMap<String,Customer> customerLogin=new HashMap<>();
    private Admin adminLogin=new Admin();
    private LinkedHashMap<String,HashMap<String,Products>> products=new LinkedHashMap<>();
    private ArrayList<Products> cart=new ArrayList<>();
    private HashMap<String,Cart> invoiceList=new HashMap<String, Cart>();


    public Customer getCustomer(String mail) {
        return customerLogin.get(mail);
    }

    public void setCustomer(Customer cus){
            customerLogin.put(cus.getMail(),cus);
    }

    public HashMap customerMap(){
        return customerLogin;
    }


    public LinkedHashMap productsmap(){
        return products;
    }

    public void setAdminLogin(String mail,String password){
        adminLogin.setPassword(password);
        adminLogin.setMail(mail);
    }

    public Admin getadmin() {
        return adminLogin;
    }

    public void addToCart(Products products,String mail) {
        cart.add(products);
    }

    public List<Products> checkout(String mail) {
        invoiceList.put(mail,new Cart());
       Cart cus=invoiceList.getOrDefault(mail,new Cart());
       cus.setInvoiceNumber(invoice++);
       List<Products> items=cus.getInvoiceList();
       if(items==null)
           items=new ArrayList<>();

       for(Products pro:cart)
          items.add(pro);

       cus.setInvoiceList(items);
       invoiceList.put(mail,cus);
       cart.clear();
        return items;
    }

    public Cart getInvoiceList(String mail) {
        return invoiceList.get(mail);
    }

    public void setProductsMap(Products cus) {
        HashMap<String,Products> map=products.getOrDefault(cus.getCategory(),new HashMap<>());
        map.put(cus.getBrand(),cus);
        products.put(cus.getCategory(),map);
    }

    public static void main(String[] args) {
        Logical user=new Logical();
        user.fileReader();
        user.itemsReader();
        HashMap<String,Customer> customerLogin= INSTANCE.customerMap();
        for(Map.Entry<String,Customer> map:customerLogin.entrySet()){
            System.out.println(map.getKey()+map.getValue());
        }
    }

}
